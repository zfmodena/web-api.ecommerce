<?
$arr_master_product_related[1049] = array(1050,1051,1052, 622 ) ;
$arr_master_product_related[1050] = array(1049,1051,1052, 622 ) ;
$arr_master_product_related[1051] = array(1049,1050,1052, 622 ) ;
$arr_master_product_related[1052] = array(1049,1050,1051, 622 ) ;
$arr_master_product_related[1152] = array(1153,1154) ;
$arr_master_product_related[1153] = array(1152,1154) ;
$arr_master_product_related[1154] = array(1152,1153) ;
$arr_master_product_related[1301] = array(1299,1300) ;
$arr_master_product_related[1299] = array(1301,1300) ;
$arr_master_product_related[1300] = array(1299,1301) ;
$arr_master_product_related[1344] = array(1299,1301) ;
$arr_master_product_related[1359] = array(1359,1360) ;
$arr_master_product_related[1360] = array(1360,1359) ;

?>