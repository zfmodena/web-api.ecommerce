<?
		include "mainclass.php";
		include_once "ext/harbolnas2016.php";
		$ekstensi_perhitungan_diskon = ekstensi_perhitungan_diskon(855);
		if( $ekstensi_perhitungan_diskon != 0 ) echo $ekstensi_perhitungan_diskon;
		echo "tidak masuk";

?>