<?

$order_status = 0;
include "cart_sync_checkout.php";

?>